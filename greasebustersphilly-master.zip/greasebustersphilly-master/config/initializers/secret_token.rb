# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Greasebustersphilly::Application.config.secret_token = '30e7fb1cc84d38aec37b73c86e7e152dd9ebe5621cfa682f22c4b3635f952b7c1bf5d902a90e00d7293b495e0b1570fe9736b748c60b1a12df63d81bfbd335a6'
